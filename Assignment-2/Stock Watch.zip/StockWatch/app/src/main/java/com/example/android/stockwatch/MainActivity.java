package com.example.android.stockwatch;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputFilter;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.widget.Toast.LENGTH_SHORT;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, View.OnLongClickListener {

    private static final String TAG = "MainActivity";

    private RecyclerView rView;
    private StockAdapter stockAdapter;
    private  SQLiteDB sqlDatabase;
    SwipeRefreshLayout swipeRefreshLayout;

    private final List<StockDetails> stockDetails = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rView = findViewById(R.id.recyclerView);
        swipeRefreshLayout = findViewById(R.id.swipeContainer);

        stockAdapter = new StockAdapter(stockDetails,this);
        rView.setAdapter(stockAdapter);
        rView.setLayoutManager(new LinearLayoutManager(this));

        sqlDatabase = new SQLiteDB(this);
        ArrayList<StockDetails> tempList = sqlDatabase.loadStocks();


        if(!isConnectedToNetwork())
        {
            errorDialog();
            stockDetails.addAll(tempList);
            Collections.sort(stockDetails, new Comparator<StockDetails>() {
                @Override
                public int compare(StockDetails o1, StockDetails o2) {
                    return o1.getStockSymbol().compareTo(o2.getCmpName());
                }
            });
            stockAdapter.notifyDataSetChanged();
        }
        else
        {
            for(int i=0;i<tempList.size();i++)
            {
                String symbol = tempList.get(i).getStockSymbol();
                new StockDownloader(this).execute(symbol);
            }

        }

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (!isConnectedToNetwork()) {
                    swipeRefreshLayout.setRefreshing(false);
                    errorDialog();
                } else {
                    refreshDataOnSwipe();
                }
            }
        });
    }

    public void refreshDataOnSwipe(){
        if(stockDetails.size() == 0){
            swipeRefreshLayout.setRefreshing(false);
            Toast.makeText(this,"No data in the display list to Refresh!",Toast.LENGTH_LONG).show();
        }else {
            swipeRefreshLayout.setRefreshing(false);
            stockDetails.clear();
            ArrayList<StockDetails> list = sqlDatabase.loadStocks();
            for (int i = 0; i < list.size(); i++) {
                String symbol = list.get(i).getStockSymbol();
                new StockDownloader(MainActivity.this).execute(symbol);
            }
            Toast.makeText(this,"Data Refreshed!",Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: " + stockDetails.size());
        stockAdapter.notifyDataSetChanged();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.add_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        if (item.getItemId() == R.id.addanitem)
        {
            addStock();
            return true;
        }else if(item.getItemId() == R.id.deleteEntry){
            if(stockDetails.size() == 0){
                displayNothingToDeleteDialog();
            }else {
                androidx.appcompat.app.AlertDialog.Builder deleteAlert= new androidx.appcompat.app.AlertDialog.Builder(this);
                deleteAlert.setTitle("Remove All?");
                deleteAlert.setMessage("Confirming this will remove all the records!");
                deleteAlert.setCancelable(true);
                deleteAlert.setPositiveButton("Remove", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        stockDetails.removeAll(stockDetails);
                        ArrayList<StockDetails> allRecords = sqlDatabase.loadStocks();
                        for(int i=0;i<allRecords.size();i++){
                            sqlDatabase.deleteStock(allRecords.get(i).getStockSymbol());
                        }
                        stockAdapter.notifyDataSetChanged();
                        ItemsRemovedConfirmationDialog();
                    }
                });
                deleteAlert.setIcon(R.drawable.baseline_delete_24);
                deleteAlert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                deleteAlert.show();
            }
            return true;
        }
        else
        {
            return super.onOptionsItemSelected(item);
        }
    }
    public void displayNothingToDeleteDialog(){
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Delete");
        builder.setMessage("All the stocks in the list are already removed!");
        android.app.AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
    public void ItemsRemovedConfirmationDialog(){
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Removed!");
        builder.setMessage("All the Stocks in Display are removed!");
        android.app.AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
    @Override
    public void onClick(View view) {
        int i = rView.getChildLayoutPosition(view);
        String marketPlaceURL = "http://www.marketwatch.com/investing/stock/" + stockDetails.get(i).getStockSymbol();
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(marketPlaceURL));
        startActivity(intent);
    }

    @Override
    public boolean onLongClick(View view) {
        final int id = rView.getChildLayoutPosition(view);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Stock");
        builder.setMessage("Delete Stock Symbol " + ((TextView) view.findViewById(R.id.stockSymbol)).getText().toString() + "?");
        builder.setPositiveButton("DELETE", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                sqlDatabase.deleteStock(stockDetails.get(id).getStockSymbol());
                stockDetails.remove(id);
                stockAdapter.notifyDataSetChanged();
                Toast.makeText(MainActivity.this, "Stock Deleted", Toast.LENGTH_SHORT).show();
            }
        }).setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                return;
            }
        });
        builder.setIcon(R.drawable.baseline_delete_24);
        AlertDialog dialog = builder.create();
        dialog.show();
        return false;
    }


    public void addStock()
    {

        if(isConnectedToNetwork())
        {
            final EditText symbolEditText = new EditText(this);
            symbolEditText.setFilters(new InputFilter[] {new InputFilter.AllCaps()});
            symbolEditText.setGravity(Gravity.CENTER_HORIZONTAL);
            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setTitle("Stock Selection")
                    .setMessage("Please enter a Stock Symbol:")
                    .setView(symbolEditText)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            String symbol = String.valueOf(symbolEditText.getText());
                           getStockSymbols(symbol);
                        }
                    })
                    .setIcon(R.drawable.baseline_show_chart_black_24)
                    .setNegativeButton("Cancel", null)
                    .create();
            dialog.show();
        }
        else
        {
            errorDialog();
        }

    }

    public void errorDialog()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("No Network Connection");
        builder.setMessage("Stocks Cannot Be Added Without A Network Connection");
        builder.setIcon(R.drawable.baseline_warning_24);
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    public boolean isConnectedToNetwork()
    {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if(cm == null)
        {
            Toast.makeText(this,"Cannot access ConnectivityManager", LENGTH_SHORT).show();
            return false;
        }

        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
        return networkInfo != null && networkInfo.isConnected();
    }

    public void getStockSymbols(String s) { new NameDownloader(this).execute(s); }

    public void StockSymbols(String s, final HashMap<String,String> result)
    {
        //result = new HashMap<>();

        if(result.size() == 0) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Symbol Not Found: " + s);
            builder.setMessage("Data for stock symbol");
            AlertDialog dialog = builder.create();
            dialog.show();


        }

        else if (result.size() == 1) {
            addDetails(s);
        }

        else if (result.size() > 1){
            final String[] res = new String[result.size()];
            int i = 0;
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Make a selection");
            for (Map.Entry<String,String> entry : result.entrySet())
            {
               // int i = 0;
                String display = entry.getKey() + " - " + entry.getValue();
                res[i] = display;
                i++;
            }
            builder.setItems(res, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    String sym[] = res[i].split(" ");
                    String symbol = sym[0];

                    addDetails(symbol);

                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();


        }

    }

    public void stockData(StockDetails stock)
    {
        if (stock != null) {
            Log.d(TAG, "In Stock !=null condition");
            int index = stockDetails.indexOf(stock);
            Log.d(TAG, "The index " + index);
            if (index > -1) {
                Log.d(TAG, "In Stock index");
                stockDetails.remove(index);
            }
            stockDetails.add(stock);
            Collections.sort(stockDetails, new Comparator<StockDetails>() {
                @Override
                public int compare(StockDetails o1, StockDetails o2) {
                    return o1.getStockSymbol().compareTo(o2.getCmpName());
                }
            });
            stockAdapter.notifyDataSetChanged();
        }
    }

    public void addStockToDB(StockDetails sd)
    {
        boolean duplicateStock = false;
        if (sd != null) {
            StockDetails sd1 = new StockDetails();
            sd1.setStockSymbol(sd.getStockSymbol());
            sd1.setCmpName(sd.getCmpName());

            if(stockDetails.size() > 0)
            {
                for(StockDetails s : stockDetails)
                {
                    if((s.getStockSymbol()).equals(sd.getStockSymbol())) {
                         duplicateStock = true;
                         break;
                    }
                }

                if(duplicateStock == true)
                {
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Duplicate Stock");
                    builder.setMessage("Stock Symbol " + sd.getStockSymbol() +" is already displayed");
                    builder.setIcon(R.drawable.baseline_warning_black_24);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                else
                {
                    stockDetails.add(sd);
                    sqlDatabase.addStock(sd1);
                }
            }
            else
                stockDetails.add(sd);
            sqlDatabase.addStock(sd1);
        }
        Collections.sort(stockDetails, new Comparator<StockDetails>() {
            @Override
            public int compare(StockDetails o1, StockDetails o2) {
                return o1.getStockSymbol().compareTo(o2.getStockSymbol());
            }
        });
        stockAdapter.notifyDataSetChanged();
    }

    public void addDetails(String s) { new StockDownloader(this).execute(s); }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        sqlDatabase.shutDown();
    }


}
