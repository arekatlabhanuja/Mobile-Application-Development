package com.example.android.stockwatch;

import android.annotation.SuppressLint;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class NameDownloader extends AsyncTask<String, Void, String> {

    private static final String TAG = "NameDownloader";

    @SuppressLint("StaticFieldLeak")
    private MainActivity mActivity;
    public HashMap<String, String> Data = new HashMap<>();
    String stockSymbol;
    String StockName;

    private static final String DATA_URL = "https://api.iextrading.com/1.0/ref-data/symbols";

    NameDownloader(MainActivity ma)
    {
        mActivity = ma;
    }


    @Override
    protected String doInBackground(String... params) {

        String sym = params[0];

        Uri data_Uri = Uri.parse(DATA_URL);
        String urlToUse = data_Uri.toString();

        StringBuilder  s_b = new StringBuilder();
        try {
            URL url = new URL(urlToUse);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            InputStream is = conn.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String line;

            while ((line = br.readLine()) != null)
                s_b.append(line);

        }
        catch (Exception e)
        {
            Log.d(TAG, "doInBackground: ", e);
            return null;
        }

        parseJson(s_b.toString());
        return sym;


    }



    @Override
    protected void onPostExecute(String s)
    {
        mActivity.StockSymbols(s,getSymbols(s));





    }

    private void parseJson(String s)
    {
        try {

            JSONArray jsonArray = new JSONArray(s);

            for (int i=0; i < jsonArray.length(); i++) {

                JSONObject jsonObject = jsonArray.getJSONObject(i);
                 stockSymbol = jsonObject.getString("symbol");
                 StockName = jsonObject.getString("name");

                Data.put(stockSymbol, StockName);

            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    private HashMap<String,String> getSymbols(String s) {

       HashMap<String,String> getData = new HashMap<>();
       try {
           for (Map.Entry<String, String> entry : Data.entrySet()) {

               String s1 = (String) entry.getKey();
               if (s1.contains(s)) {
                   getData.put(entry.getKey(), entry.getValue());
               }

           }
           return getData;
       }
       catch (Exception e)
       {
           e.printStackTrace();
       }
       return null;


    }

}
